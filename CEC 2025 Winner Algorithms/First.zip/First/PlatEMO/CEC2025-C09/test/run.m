RunNumber = 31;  % 31 runs
Error = NaN(1,RunNumber);
AcceptancePoints = NaN(1,RunNumber);
ProblemNumber = 1;  % Problem index

if ProblemNumber < 16 %f1-f15
   iteration = 2000;  
   maxFE = 500000;
else                  % f16-f24
   iteration = 4000;  
   maxFE = 1000000;
end
minObjs = zeros(iteration,1);


txtFolder = fullfile(pwd, 'C09-results');   % directory of results
if ~exist(txtFolder, 'dir')  
    mkdir(txtFolder);  
end

load(sprintf('f%d.mat',ProblemNumber),'GNBG');
for RunCounter=1 : RunNumber
    disp(['RunCounter=', num2str(RunCounter)]);
   
    % if you want re-run experiments for 31 independent runs, please delete the relevant data in Data of C09 and execute the following two lines.
    % platemo('save',iteration,'run',RunCounter,'algorithm',@C09,'problem',...
    %     str2func(sprintf("GNBG_F%d",ProblemNumber)),'maxFE',maxFE);

    load(sprintf('Data/C09/C09_GNBG_F%d_M1_D30_%d.mat',ProblemNumber,RunCounter));
    
    for it = 1:iteration 
        minObjs(it) = min(result{it,2}.objs);
    end

    differences = abs(minObjs - GNBG.OptimumValue);
    index = find(differences <= GNBG.AcceptanceThreshold, 1);  

    if isempty(index)
        index = NaN;  
        AcceptancePoints(RunCounter) = Inf; 
    else
        AcceptancePoints(RunCounter) = result{index,1}; 
    end
    BestFoundResult = min(result{end,2}.objs);
    Error(1,RunCounter) = abs(BestFoundResult - GNBG.OptimumValue);

   
    problemFolder = fullfile(txtFolder, sprintf("GNBG_F%d",ProblemNumber)); 
    if ~exist(problemFolder, 'dir')  
        mkdir(problemFolder);  
    end
    fileName = fullfile(problemFolder, sprintf("GNBG_F%d.txt", ProblemNumber));
    fileID = fopen(fileName, 'a');  
    if fileID == -1
        error('open failure!');
    end
    if ftell(fileID) == 0
        fprintf(fileID, 'Error\t\t\tAcceptancePoints\n');  
    end
    fprintf(fileID, '%g\t\t\t\t%g\n', Error(1, RunCounter), AcceptancePoints(RunCounter));
    fclose(fileID);
end


nonInfIndices = isfinite(AcceptancePoints);
nonInfValues = AcceptancePoints(nonInfIndices);



fileID = fopen(fileName, 'a');
if fileID == -1
    error('open failure!');
end

fprintf(fileID, '\n=========== Summary ===========\n');
fprintf(fileID, 'Average FE to reach acceptance result: %g (%g)\n', mean(nonInfValues), std(nonInfValues));
fprintf(fileID, 'Acceptance Ratio: %g%%\n', (sum(nonInfIndices) / length(AcceptancePoints)) * 100);
fprintf(fileID, 'Final result (Error): %g (%g)\n', mean(Error(1,:)), std(Error(1,:)));
fprintf(fileID, '===============================\n\n');

fclose(fileID);  

% disp results in operand window
fprintf("===========Prolem GNBG_F%d %d runs Complete=========:\n",ProblemNumber,RunNumber);
disp(['Average FE to reach acceptance result: ', num2str(mean(nonInfValues)),'(',num2str(std(nonInfValues)),')']);
disp(['Acceptance Ratio: ',num2str((sum(nonInfIndices) / length(AcceptancePoints)) * 100)]);
disp(['Final result: ',num2str(mean(Error(1,:))),'(',num2str(std(Error(1,:))),')']);
fprintf("======================================================\n");       