classdef C09 < ALGORITHM % < ALGORITHM
% <2025> <single> <real>
% GEA for GNBG f1-f24

%------------------------------- Copyright --------------------------------
% Copyright (c) 2024 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------
    methods
        function main(Algorithm,Problem)
   
            data = load('C09.mat','Blocks','Graph');
            Blocks = data.Blocks;Graph = data.Graph;
            epsilon = 1e-10;
            isPop = arrayfun(@(s)isa(s,'Block_Population'),Blocks(:)');
            Blocks(isPop).Initialization(Problem.Initialization()); 
            Population = Blocks(1).output;
            len = length(Blocks);
            index = 2:size(Blocks(1,len).Weight,2)-1;
            temp = Blocks(1,len).Weight(:, index);
            if (rand < 0.1)
                Blocks(1,len).Weight(:,index) = temp+epsilon*rand;
            else
                Blocks(1,len).Weight(:,index) = temp;
            end
            %% Optimization
            while Algorithm.NotTerminated(Population)
                activated = false(1,length(Blocks));
                while ~all(activated(isPop))
                    for i = find(~activated)
                        if all(activated(logical(Graph(:,i)))|isPop(logical(Graph(:,i))))
                        	Blocks(i).Main(Problem,Blocks(logical(Graph(:,i))),Graph(:,i));
                            activated(i) = true;       
                        end
                    end
                end
                Population = Blocks(1).output;
            end
        end
    end
end