classdef GNBG_F17 < PROBLEM
% <2025> <single> <real>
% Generated numerical optimization benchmark problem

%------------------------------- Reference --------------------------------
% Danial Yazdani, Mohammad Nabi Omidvar, Delaram Yazdani, Kalyanmoy Deb, 
% Amir H. Gandomi, "GNBG: A Generalized and Configurable Benchmark 
% Generator for Continuous Numerical Optimization," arXiv preprint 
% arXiv:2312.07083, 2023.
%------------------------------- Copyright --------------------------------
% Copyright (c) 2025 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    properties
        O;  % Optimal decision vector
        MaxEvals;
        G;
    end
    methods
        %% Default settings of the problem
        function Setting(obj)
            CallStack = dbstack('-completenames');
            load(fullfile(fileparts(CallStack(1).file),'f17.mat'),'GNBG');
            obj.MaxEvals = GNBG.MaxEvals;
            obj.O = GNBG.OptimumPosition;
            obj.G = GNBG;
            obj.M = 1;
            if isempty(obj.D); obj.D = GNBG.Dimension; end
            obj.D = min(obj.D,length(obj.O));
            obj.lower    = zeros(1,obj.D) + GNBG.MinCoordinate;
            obj.upper    = zeros(1,obj.D) + GNBG.MaxCoordinate;
            obj.encoding = ones(1,obj.D);
        end
        %% Calculate objective values
        function PopObj= CalObj(obj,PopDec)
            PopObj = fitness(PopDec,obj.G);
        end
    end
end

%%-------------------------GNBG Fitness----------------------------------%%
function [result,GNBG] = fitness(X,GNBG)

      [SolutionNumber,~] = size(X);
      result = NaN(SolutionNumber,1);
      for jj=1 : SolutionNumber
          x = X(jj,:)';
          f=NaN(1,GNBG.o);
          for k=1 : GNBG.o
              a = Transform((x - GNBG.Component_MinimumPosition(k,:)')'*GNBG.RotationMatrix(:,:,k)',GNBG.Mu(k,:),GNBG.Omega(k,:));
              b = Transform(GNBG.RotationMatrix(:,:,k) * (x - GNBG.Component_MinimumPosition(k,:)'),GNBG.Mu(k,:),GNBG.Omega(k,:));
              f(k) = GNBG.ComponentSigma(k) + ( a * diag(GNBG.Component_H(k,:)) * b)^GNBG.lambda(k);
          end
          result(jj) = min(f);
          if GNBG.FE > GNBG.MaxEvals
              return;
          end
          GNBG.FE = GNBG.FE + 1;
          GNBG.FEhistory(GNBG.FE) = result(jj);
          %%
          if GNBG.BestFoundResult > result(jj)
              GNBG.BestFoundResult = result(jj);
          end
          if (abs(GNBG.FEhistory(GNBG.FE) - GNBG.OptimumValue)) < GNBG.AcceptanceThreshold && isinf(GNBG.AcceptanceReachPoint)
              GNBG.AcceptanceReachPoint = GNBG.FE;
          end
          %%
      end
end

function Y = Transform(X,Alpha,Beta)
Y = X;
tmp = (X > 0);
Y(tmp) = log(X(tmp));
Y(tmp) = exp(Y(tmp) + Alpha(1)*(sin(Beta(1).*Y(tmp)) + sin(Beta(2).*Y(tmp))));
tmp = (X < 0);
Y(tmp) = log(-X(tmp));
Y(tmp) = -exp(Y(tmp) + Alpha(2)*(sin(Beta(3).*Y(tmp)) + sin(Beta(4).*Y(tmp))));
end

%-------------------------------------------------------------------------%